# 📊 E-Commerce Sales Data Analysis

An end-to-end data analysis project exploring **2 years (2024–2025) of e-commerce order data** — uncovering revenue trends, category & regional performance, payment behavior, and return patterns.

## 🎯 Objective
To analyze e-commerce sales data and extract actionable business insights around **revenue growth, customer behavior, and operational patterns** (returns, discounts, payments) that could inform business strategy.

## 🗂️ Dataset
- 5,000 synthetic but realistic order records (Jan 2024 – Dec 2025)
- Fields: `order_id`, `order_date`, `category`, `price`, `quantity`, `discount_pct`, `revenue`, `region`, `payment_method`, `is_returned`, `customer_rating`
- 5 product categories, 5 regions, 5 payment methods
- Includes realistic seasonality (festive season boost) and discount/return dynamics

> Note: Dataset is synthetically generated (`data/generate_data.py`) to keep the project fully reproducible and shareable without privacy concerns — while modeling realistic e-commerce patterns.

## 🛠️ Tech Stack
- **Python** — pandas, numpy
- **Visualization** — matplotlib, seaborn
- **Analysis** — Exploratory Data Analysis (EDA), aggregation, trend analysis

## 📈 Key Insights

- **Total Revenue:** ₹4.09 Cr across 5,000 orders | **Avg Order Value:** ₹8,184
- **Electronics** is the top revenue-generating category, followed by Home & Kitchen
- **North region** leads with ~29% of total revenue share
- **UPI** is the most preferred payment method (42% of orders)
- **Overall return rate:** 5.2% — and interestingly, deeper discounts do **not** correlate with higher returns
- Clear **festive season spike (Oct–Dec)**, peaking in November — useful signal for inventory & marketing planning

## 📊 Visualizations

| Chart | Insight |
|---|---|
| `01_monthly_revenue_trend.png` | Revenue seasonality & festive season spikes |
| `02_revenue_by_category.png` | Which categories drive the most revenue |
| `03_revenue_by_region.png` | Regional revenue distribution |
| `04_payment_methods.png` | Payment method popularity vs. avg order value |
| `05_discount_vs_returns.png` | Relationship between discount depth and return rate |
| `06_rating_distribution.png` | Customer satisfaction distribution |

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib seaborn
python data/generate_data.py   # generates the dataset
python analysis.py             # runs analysis & saves charts to /visuals
```

## 📁 Project Structure
```
ecommerce-sales-analysis/
├── data/
│   ├── generate_data.py
│   └── ecommerce_sales.csv
├── visuals/
│   └── *.png (6 charts)
├── analysis.py
├── insights.txt
└── README.md
```

## 🔮 Future Improvements
- Add cohort/RFM analysis for customer segmentation
- Build an interactive dashboard (Plotly Dash / Streamlit)
- Forecast next-quarter revenue using time-series models

---
*Feel free to fork this repo and adapt it to a real dataset — the analysis pipeline is fully modular.*
