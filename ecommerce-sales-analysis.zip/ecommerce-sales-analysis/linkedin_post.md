📊 New Project: E-Commerce Sales Data Analysis

Maine recently ek end-to-end data analysis project complete kiya — 5,000 e-commerce orders (2 saal ka data) analyze karke business insights nikale.

🔍 Kya explore kiya:
✅ Revenue trends & seasonality (festive season spike detected!)
✅ Category & regional performance
✅ Payment method behavior
✅ Discount vs return-rate relationship
✅ Customer satisfaction patterns

🛠️ Tech Stack: Python, Pandas, Matplotlib, Seaborn

💡 Key takeaway: Deeper discounts didn't actually correlate with higher return rates — a good reminder that assumptions should always be data-validated before decision-making.

Poora project (code + visuals + insights) GitHub par hai 👇
[apna GitHub link yahan daalein]

#DataAnalysis #Python #DataScience #EDA #Pandas #DataVisualization #Analytics #PortfolioProject
